Install instructions:

1. Navigate to the civ directory and build with dune build
2. To play the game, type dune exec bin/main.exe
