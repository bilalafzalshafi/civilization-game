let total_round = 20
let map_size = 10
let claim_reward = 10
let build_reward = 20
let build_cost = 50
